# Queue insertion and deletion

class SinglyQueue:

    def __init__(self, size=10):
        self.queue = []
        self.size = size
        self.rear = -1

    def insert(self, value):

        if self.rear == self.size - 1:
            print("Queue is full")
            return

        self.rear += 1
        self.queue.append(value)
        print(f"Item {value} inserted successfully")

    def delete(self):

        if self.rear == -1:
            print("Queue is empty")
            return

        item = self.queue.pop(0)
        self.rear -= 1
        print(f"Item {item} deleted successfully")

    def display(self):

        if self.rear == -1:
            print("Queue is empty")
        else:
            print("Queue elements:", self.queue)


obj = SinglyQueue()

while True:

    print("\n1. Insert")
    print("2. Delete")
    print("3. Display")
    print("4. Exit")

    ch = int(input("Enter your choice: "))

    match ch:

        case 1:
            item = int(input("Enter item to insert: "))
            obj.insert(item)

        case 2:
            obj.delete()

        case 3:
            obj.display()

        case 4:
            break

