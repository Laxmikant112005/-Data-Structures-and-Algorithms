# Finding the largest number in an array

num = [12,35,1,10,34,1]
n = num[0]
for i in num:
    if i >= n:
        n = i
    else:
        continue
print(n)

# Finding the smallest number in an array

nums = [1, 2, 4, 5, 6, 7, 8, 9, 10]
size = len(nums)
j,t = 1,1
for i in range(size):

    if j >= size:  
        break

    gap = nums[j] - nums[i]
    if gap != 1:
        print(f"Number {nums[i]} is present with gap {1}")
        print(f"\nMissing number is {j+t} with gap {gap}\n")
        j += 1
        t += 1
    else:
        j += 1
        print(f"Number {nums[i]} is present with gap {gap}")

# Finding the missing number in an array

nums = [1, 2, 4, 5, 6, 7, 8, 9, 10]

n = len(nums) + 1
xor_all = 0
xor_nums = 0

for i in range(1, n + 1):
    xor_all ^= i

for num in nums:
    xor_nums ^= num

print("Missing number is:", xor_all ^ xor_nums)

# removing duplicates from an array

nums = [4, 5, 2, 4, 1, 2, 5, 9]
res = []
j = 0
for i in nums:
    if i not in res:
        res.append(i)
        j += 1
print(res)

# Finding the majority element in an array

nums = [3, 3, 4, 2, 4, 4, 2, 4, 4]

candidate = None
count = 0

for num in nums:
    if count == 0:
        candidate = num
        
    if num == candidate:
        count += 1
    else:
        count -= 1

print("Majority element is:", candidate)

# Rotating an array by k positions

nums = [1, 2, 3, 4, 5]
k = 2

res = []
n = len(nums)

k = k % n   # safety step

for i in range(n - k, n):
    res.append(nums[i])

for i in range(0, n - k):
    res.append(nums[i])

print(res)


# Finding the single number in an array where every element appears twice except for one


arr = [2, 2, 3, 4, 4, 5, 5]
n = len(arr)
res = 0
for i in arr:
    res = res ^ i
print(res)

# finding the single number in an array where every element appears twice except for one using list

#wrong code
arr = [2, 2, 3, 4, 4, 5, 5]
arr_r = []
res = 0
n = 1
for i in arr:
    for j in range(i + 1, n):
        if i == arr_r[j]:
            arr_r.remove(i)
            n -= 1
        else:
            arr_r.append(i)
            n += 1

print(arr_r) 

#current code
arr = [2, 2, 3, 4, 4, 5, 6, 7, 6]
res = []
for i in arr:
    if i not in res:
        res.append(i)
    else:
        res.remove(i)
print(res)

# counting the frequency of each element in an array

arr = [ 2, 3, 4, 2, 1, 1, 3, 2]
res = []
for i in arr:
    if i not in res:
        res.append(i)
    else:
        pass

for j in res:
    count = 0
    for i in arr:
        if i == j:
            count += 1
        else:
            pass
    print(f"{j} -> {count}")


# moving all zeros to the end of an array

arr = [2, 3, 0, 4, 0, 5]

for i in arr:
    if i == 0:
        arr.remove(0)
        arr.append(0)
    else:
        pass

print(arr)


# Finding the maximum profit from stock prices

def max_profit(prices):

# Start with the highest possible value
    min_price = float('inf') 
    max_profit = 0
    
    for price in prices:
        # Update the lowest price found so far
        if price < min_price:
            min_price = price
        # Calculate profit if we sold today
        elif price - min_price > max_profit:
            max_profit = price - min_price
            
    return max_profit

print(f"Max Profit: {max_profit([7, 1, 5, 3, 6, 4])}") 

# Grouping anagrams together

from collections import defaultdict

def group_anagrams(strs):
    # Using defaultdict avoids errors when a key doesn't exist yet
    groups = defaultdict(list)
    
    for word in strs:
        # Sort the word to create a unique key: "eat" -> "aet"
        sorted_key = "".join(sorted(word))
        groups[sorted_key].append(word)
    
    return list(groups.values())

words = ["eat", "tea", "tan", "ate", "nat", "bat"]
print(f"Grouped Anagrams: {group_anagrams(words)}")

# Finding the missing number in an array

def find_missing_number(nums):
    n = len(nums)
    # The sum we expect: (n * (n + 1)) / 2
    expected_sum = n * (n + 1) // 2
    actual_sum = sum(nums)
    
    return expected_sum - actual_sum

# Test
print(f"Missing Number: {find_missing_number([3, 0, 1])}") # Output: 2


# sorting concepts **************** 

# Bubble sort algorithm

arr = [ 20, 10, 5, 40, 100, 77, 50 ]
len = len(arr) 

for i in range(len):
    for j in range(len - 1 ):

        if arr[j] > arr[j+1]:
            arr[j], arr[j+1] = arr[j+1], arr[j]
            
print(arr)

# Selection sort algorithm

arr = [99, 40, 10, 25, 77, 100]
n = len(arr)

for i in range(n):

    min_index = i

    for j in range(i + 1, n):
        if arr[j] < arr[min_index]:
            min_index = j

    print(f"Swapping {arr[i]} and {arr[min_index]}")
    arr[i], arr[min_index] = arr[min_index], arr[i]

print("Sorted array:", arr)


# quick sort algorithm 

def partition(array, low, high):
    pivot = array[high]
    i = low - 1

    for j in range(low, high):
        if array[j] <= pivot:
            i += 1
            array[i], array[j] = array[j], array[i]

    array[i+1], array[high] = array[high], array[i+1]
    return i+1

def quicksort(array, low=0, high=None):
    if high is None:
        high = len(array) - 1

    if low < high:
        pivot_index = partition(array, low, high)
        quicksort(array, low, pivot_index-1)
        quicksort(array, pivot_index+1, high)

my_array = [64, 34, 25, 12, 22, 11, 90, 5]
quicksort(my_array)
print("Sorted array:", my_array)


# quick sort algorithm in descending order

def partition( arr, lb, ub ):
    piot = arr[lb]
    start = lb
    end = ub
    while(end > start ):
        while( arr[start] <= piot ):
            start += 1
            
        while( arr[end] > piot ):
            end -= 1
            
        if end > start :
            temp = arr[start]
            arr[start]=arr[end]
            arr[end] = temp
    
    temp = arr[lb]
    arr[lb] = arr[end]
    arr[end] = temp
    return end 

def quick_sort( arr, lb, ub ):
    if lb < ub:
        loc = partition( arr, lb, ub )
        quick_sort( arr, lb, loc - 1)
        quick_sort( arr, loc + 1, ub )

arr = [ 20, 1, 30, 2, 5, 10, 15 ]
quick_sort(arr, 0, len(arr) - 1 )

print(" Sorted array is : ", arr )



def partition(arr, lb, ub):
    pivot = arr[lb]
    start = lb + 1
    end = ub

    while start <= end:
        while start <= ub and arr[start] <= pivot:
            start += 1

        while arr[end] > pivot:
            end -= 1

        if start < end:
            arr[start], arr[end] = arr[end], arr[start]

    arr[lb], arr[end] = arr[end], arr[lb]
    return end


def quick_sort(arr, lb, ub):
    if lb < ub:
        loc = partition(arr, lb, ub)
        quick_sort(arr, lb, loc - 1)
        quick_sort(arr, loc + 1, ub)


arr = [20, 1, 30, 2, 5, 10, 15]
quick_sort(arr, 0, len(arr) - 1)

print("Sorted array is:", arr)


# linear search algorithm

def linear_search(arr, key):
    for i in range(len(arr)):
        if arr[i] == key:
            return i
    return -1

test_arr = [99, 40, 10, 25, 77, 100]
key_to_find = 77
result = linear_search(test_arr, key_to_find)
if result != -1:
    print(f"Element {key_to_find} found at index {result}")
else:
    print(f"Element {key_to_find} not found in the array")

# binary search algorithm

def binary_search(arr, key):
    low = 0
    high = len(arr) - 1

    while low <= high:
        mid = (low + high) // 2

        if arr[mid] == key:
            return mid
        elif arr[mid] < key:
            low = mid + 1
        else:
            high = mid - 1

    return -1

test_arr = [10, 25, 40, 77, 99, 100] # must be sorted
key_to_find = 77
result = binary_search(test_arr, key_to_find)
if result != -1:
    print(f"Element {key_to_find} found at index {result}")
else:
    print(f"Element {key_to_find} not found in the array")
